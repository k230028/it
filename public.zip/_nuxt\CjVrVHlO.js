import{n as e}from"./Dd_uD5pT.js";import{_ as t,b as n,et as r,mt as i,xt as a,y as o}from"./BX3QIp9d.js";import{t as s}from"./DWv9zje-.js";import{t as c}from"./Bh2RCD2L.js";var l=s.extend({name:`card`,style:`
    .p-card {
        background: dt('card.background');
        color: dt('card.color');
        box-shadow: dt('card.shadow');
        border-radius: dt('card.border.radius');
        display: flex;
        flex-direction: column;
    }

    .p-card-caption {
        display: flex;
        flex-direction: column;
        gap: dt('card.caption.gap');
    }

    .p-card-body {
        padding: dt('card.body.padding');
        display: flex;
        flex-direction: column;
        gap: dt('card.body.gap');
    }

    .p-card-title {
        font-size: dt('card.title.font.size');
        font-weight: dt('card.title.font.weight');
    }

    .p-card-subtitle {
        color: dt('card.subtitle.color');
    }
`,classes:{root:`p-card p-component`,header:`p-card-header`,body:`p-card-body`,caption:`p-card-caption`,title:`p-card-title`,subtitle:`p-card-subtitle`,content:`p-card-content`,footer:`p-card-footer`}}),u=e({default:()=>d}),d={name:`Card`,extends:{name:`BaseCard`,extends:c,style:l,provide:function(){return{$pcCard:this,$parentInstance:this}}},inheritAttrs:!1};function f(e,s,c,l,u,d){return i(),n(`div`,r({class:e.cx(`root`)},e.ptmi(`root`)),[e.$slots.header?(i(),n(`div`,r({key:0,class:e.cx(`header`)},e.ptm(`header`)),[a(e.$slots,`header`)],16)):o(``,!0),t(`div`,r({class:e.cx(`body`)},e.ptm(`body`)),[e.$slots.title||e.$slots.subtitle?(i(),n(`div`,r({key:0,class:e.cx(`caption`)},e.ptm(`caption`)),[e.$slots.title?(i(),n(`div`,r({key:0,class:e.cx(`title`)},e.ptm(`title`)),[a(e.$slots,`title`)],16)):o(``,!0),e.$slots.subtitle?(i(),n(`div`,r({key:1,class:e.cx(`subtitle`)},e.ptm(`subtitle`)),[a(e.$slots,`subtitle`)],16)):o(``,!0)],16)):o(``,!0),t(`div`,r({class:e.cx(`content`)},e.ptm(`content`)),[a(e.$slots,`content`)],16),e.$slots.footer?(i(),n(`div`,r({key:1,class:e.cx(`footer`)},e.ptm(`footer`)),[a(e.$slots,`footer`)],16)):o(``,!0)],16)],16)}d.render=f;export{d as n,u as t};