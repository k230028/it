import{n as e}from"./Dd_uD5pT.js";import{D as t,St as n,_ as r,b as i,et as a,mt as o,qt as s,tr as c,v as l,wt as u,xt as d,y as f}from"./BX3QIp9d.js";import{t as p}from"./BEaavq_b.js";import{D as m,F as h,Q as g,l as _,m as v,t as y}from"./DWv9zje-.js";import{t as b}from"./CRHlWn3X.js";import{t as x}from"./cO8iUN-n.js";import{t as S}from"./D3RJIeFz.js";import{t as C}from"./DO7uS3Da.js";import{t as w}from"./BBbgMIMV2.js";import{t as T}from"./Bb4nrzQZ2.js";import{n as E}from"./CZBCK6KA2.js";import{t as D}from"./DzmtD0zQ2.js";import{t as O}from"./_s8140ec.js";import{t as k}from"./C6xklmmL2.js";var A={name:`EyeSlashIcon`,extends:C};function j(e){return F(e)||P(e)||N(e)||M()}function M(){throw TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function N(e,t){if(e){if(typeof e==`string`)return I(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?I(e,t):void 0}}function P(e){if(typeof Symbol<`u`&&e[Symbol.iterator]!=null||e[`@@iterator`]!=null)return Array.from(e)}function F(e){if(Array.isArray(e))return I(e)}function I(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function L(e,t,n,s,c,l){return o(),i(`svg`,a({width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`},e.pti()),j(t[0]||=[r(`path`,{"fill-rule":`evenodd`,"clip-rule":`evenodd`,d:`M13.9414 6.74792C13.9437 6.75295 13.9455 6.757 13.9469 6.76003C13.982 6.8394 14.0001 6.9252 14.0001 7.01195C14.0001 7.0987 13.982 7.1845 13.9469 7.26386C13.6004 8.00059 13.1711 8.69549 12.6674 9.33515C12.6115 9.4071 12.54 9.46538 12.4582 9.50556C12.3765 9.54574 12.2866 9.56678 12.1955 9.56707C12.0834 9.56671 11.9737 9.53496 11.8788 9.47541C11.7838 9.41586 11.7074 9.3309 11.6583 9.23015C11.6092 9.12941 11.5893 9.01691 11.6008 8.90543C11.6124 8.79394 11.6549 8.68793 11.7237 8.5994C12.1065 8.09726 12.4437 7.56199 12.7313 6.99995C12.2595 6.08027 10.3402 2.8014 6.99732 2.8014C6.63723 2.80218 6.27816 2.83969 5.92569 2.91336C5.77666 2.93304 5.62568 2.89606 5.50263 2.80972C5.37958 2.72337 5.29344 2.59398 5.26125 2.44714C5.22907 2.30031 5.2532 2.14674 5.32885 2.01685C5.40451 1.88696 5.52618 1.79021 5.66978 1.74576C6.10574 1.64961 6.55089 1.60134 6.99732 1.60181C11.5916 1.60181 13.7864 6.40856 13.9414 6.74792ZM2.20333 1.61685C2.35871 1.61411 2.5091 1.67179 2.6228 1.77774L12.2195 11.3744C12.3318 11.4869 12.3949 11.6393 12.3949 11.7983C12.3949 11.9572 12.3318 12.1097 12.2195 12.2221C12.107 12.3345 11.9546 12.3976 11.7956 12.3976C11.6367 12.3976 11.4842 12.3345 11.3718 12.2221L10.5081 11.3584C9.46549 12.0426 8.24432 12.4042 6.99729 12.3981C2.403 12.3981 0.208197 7.59135 0.0532336 7.25198C0.0509364 7.24694 0.0490875 7.2429 0.0476856 7.23986C0.0162332 7.16518 3.05176e-05 7.08497 3.05176e-05 7.00394C3.05176e-05 6.92291 0.0162332 6.8427 0.0476856 6.76802C0.631261 5.47831 1.46902 4.31959 2.51084 3.36119L1.77509 2.62545C1.66914 2.51175 1.61146 2.36136 1.61421 2.20597C1.61695 2.05059 1.6799 1.90233 1.78979 1.79244C1.89968 1.68254 2.04794 1.6196 2.20333 1.61685ZM7.45314 8.35147L5.68574 6.57609V6.5361C5.5872 6.78938 5.56498 7.06597 5.62183 7.33173C5.67868 7.59749 5.8121 7.84078 6.00563 8.03158C6.19567 8.21043 6.43052 8.33458 6.68533 8.39089C6.94014 8.44721 7.20543 8.43359 7.45314 8.35147ZM1.26327 6.99994C1.7351 7.91163 3.64645 11.1985 6.99729 11.1985C7.9267 11.2048 8.8408 10.9618 9.64438 10.4947L8.35682 9.20718C7.86027 9.51441 7.27449 9.64491 6.69448 9.57752C6.11446 9.51014 5.57421 9.24881 5.16131 8.83592C4.74842 8.42303 4.4871 7.88277 4.41971 7.30276C4.35232 6.72274 4.48282 6.13697 4.79005 5.64041L3.35855 4.2089C2.4954 5.00336 1.78523 5.94935 1.26327 6.99994Z`,fill:`currentColor`},null,-1)]),16)}A.render=L;var R=y.extend({name:`password`,style:`
    .p-password {
        display: inline-flex;
        position: relative;
    }

    .p-password .p-password-overlay {
        min-width: 100%;
    }

    .p-password-meter {
        height: dt('password.meter.height');
        background: dt('password.meter.background');
        border-radius: dt('password.meter.border.radius');
    }

    .p-password-meter-label {
        height: 100%;
        width: 0;
        transition: width 1s ease-in-out;
        border-radius: dt('password.meter.border.radius');
    }

    .p-password-meter-weak {
        background: dt('password.strength.weak.background');
    }

    .p-password-meter-medium {
        background: dt('password.strength.medium.background');
    }

    .p-password-meter-strong {
        background: dt('password.strength.strong.background');
    }

    .p-password-fluid {
        display: flex;
    }

    .p-password-fluid .p-password-input {
        width: 100%;
    }

    .p-password-input::-ms-reveal,
    .p-password-input::-ms-clear {
        display: none;
    }

    .p-password-overlay {
        padding: dt('password.overlay.padding');
        background: dt('password.overlay.background');
        color: dt('password.overlay.color');
        border: 1px solid dt('password.overlay.border.color');
        box-shadow: dt('password.overlay.shadow');
        border-radius: dt('password.overlay.border.radius');
    }

    .p-password-content {
        display: flex;
        flex-direction: column;
        gap: dt('password.content.gap');
    }

    .p-password-toggle-mask-icon {
        inset-inline-end: dt('form.field.padding.x');
        color: dt('password.icon.color');
        position: absolute;
        top: 50%;
        margin-top: calc(-1 * calc(dt('icon.size') / 2));
        width: dt('icon.size');
        height: dt('icon.size');
    }

    .p-password-clear-icon {
        position: absolute;
        top: 50%;
        margin-top: -0.5rem;
        cursor: pointer;
        inset-inline-end: dt('form.field.padding.x');
        color: dt('form.field.icon.color');
    }

    .p-password:has(.p-password-toggle-mask-icon) .p-password-input {
        padding-inline-end: calc((dt('form.field.padding.x') * 2) + dt('icon.size'));
    }

    .p-password:has(.p-password-toggle-mask-icon) .p-password-clear-icon {
        inset-inline-end: calc((dt('form.field.padding.x') * 2) + dt('icon.size'));
    }

    .p-password:has(.p-password-clear-icon) .p-password-input {
        padding-inline-end: calc((dt('form.field.padding.x') * 2) + dt('icon.size'));
    }

    .p-password:has(.p-password-clear-icon):has(.p-password-toggle-mask-icon)  .p-password-input {
        padding-inline-end: calc((dt('form.field.padding.x') * 3) + calc(dt('icon.size') * 2));
    }

`,classes:{root:function(e){var t=e.instance;return[`p-password p-component p-inputwrapper`,{"p-inputwrapper-filled":t.$filled,"p-inputwrapper-focus":t.focused,"p-password-fluid":t.$fluid}]},pcInputText:`p-password-input`,maskIcon:`p-password-toggle-mask-icon p-password-mask-icon`,unmaskIcon:`p-password-toggle-mask-icon p-password-unmask-icon`,clearIcon:`p-password-clear-icon`,overlay:`p-password-overlay p-component`,content:`p-password-content`,meter:`p-password-meter`,meterLabel:function(e){var t=e.instance;return`p-password-meter-label ${t.meter?`p-password-meter-`+t.meter.strength:``}`},meterText:`p-password-meter-text`},inlineStyles:{root:function(e){return{position:e.props.appendTo===`self`?`relative`:void 0}}}}),z=e({default:()=>G}),B={name:`BasePassword`,extends:T,props:{promptLabel:{type:String,default:null},mediumRegex:{type:[String,RegExp],default:`^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{6,})`},strongRegex:{type:[String,RegExp],default:`^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})`},weakLabel:{type:String,default:null},mediumLabel:{type:String,default:null},strongLabel:{type:String,default:null},feedback:{type:Boolean,default:!0},appendTo:{type:[String,Object],default:`body`},toggleMask:{type:Boolean,default:!1},hideIcon:{type:String,default:void 0},maskIcon:{type:String,default:void 0},showIcon:{type:String,default:void 0},unmaskIcon:{type:String,default:void 0},showClear:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},placeholder:{type:String,default:null},required:{type:Boolean,default:!1},inputId:{type:String,default:null},inputClass:{type:[String,Object],default:null},inputStyle:{type:Object,default:null},inputProps:{type:null,default:null},panelId:{type:String,default:null},panelClass:{type:[String,Object],default:null},panelStyle:{type:Object,default:null},panelProps:{type:null,default:null},overlayId:{type:String,default:null},overlayClass:{type:[String,Object],default:null},overlayStyle:{type:Object,default:null},overlayProps:{type:null,default:null},ariaLabelledby:{type:String,default:null},ariaLabel:{type:String,default:null},autofocus:{type:Boolean,default:null}},style:R,provide:function(){return{$pcPassword:this,$parentInstance:this}}};function V(e){"@babel/helpers - typeof";return V=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},V(e)}function H(e,t,n){return(t=U(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function U(e){var t=W(e,`string`);return V(t)==`symbol`?t:t+``}function W(e,t){if(V(e)!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t);if(V(r)!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}var G={name:`Password`,extends:B,inheritAttrs:!1,emits:[`change`,`focus`,`blur`,`invalid`],inject:{$pcFluid:{default:null}},data:function(){return{overlayVisible:!1,meter:null,infoText:null,focused:!1,unmasked:!1}},mediumCheckRegExp:null,strongCheckRegExp:null,resizeListener:null,scrollHandler:null,overlay:null,mounted:function(){this.infoText=this.promptText,this.mediumCheckRegExp=new RegExp(this.mediumRegex),this.strongCheckRegExp=new RegExp(this.strongRegex)},beforeUnmount:function(){this.unbindResizeListener(),this.scrollHandler&&=(this.scrollHandler.destroy(),null),this.overlay&&=(x.clear(this.overlay),null)},methods:{onOverlayEnter:function(e){x.set(`overlay`,e,this.$primevue.config.zIndex.overlay),m(e,{position:`absolute`,top:`0`}),this.alignOverlay(),this.bindScrollListener(),this.bindResizeListener(),this.$attrSelector&&e.setAttribute(this.$attrSelector,``)},onOverlayLeave:function(){this.unbindScrollListener(),this.unbindResizeListener(),this.overlay=null},onOverlayAfterLeave:function(e){x.clear(e)},alignOverlay:function(){this.appendTo===`self`?v(this.overlay,this.$refs.input.$el):(this.overlay.style.minWidth=g(this.$refs.input.$el)+`px`,_(this.overlay,this.$refs.input.$el))},testStrength:function(e){var t=0;return this.strongCheckRegExp.test(e)?t=3:this.mediumCheckRegExp.test(e)?t=2:e.length&&(t=1),t},onInput:function(e){this.writeValue(e.target.value,e),this.$emit(`change`,e)},onFocus:function(e){this.focused=!0,this.feedback&&(this.setPasswordMeter(this.d_value),this.overlayVisible=!0),this.$emit(`focus`,e)},onBlur:function(e){this.focused=!1,this.feedback&&(this.overlayVisible=!1),this.$emit(`blur`,e)},onKeyUp:function(e){if(this.feedback){var t=e.target.value,n=this.checkPasswordStrength(t),r=n.meter,i=n.label;if(this.meter=r,this.infoText=i,e.code===`Escape`){this.overlayVisible&&=!1;return}this.overlayVisible||=!0}},setPasswordMeter:function(){if(!this.d_value){this.meter=null,this.infoText=this.promptText;return}var e=this.checkPasswordStrength(this.d_value),t=e.meter,n=e.label;this.meter=t,this.infoText=n,this.overlayVisible||=!0},checkPasswordStrength:function(e){var t=null,n=null;switch(this.testStrength(e)){case 1:t=this.weakText,n={strength:`weak`,width:`33.33%`};break;case 2:t=this.mediumText,n={strength:`medium`,width:`66.66%`};break;case 3:t=this.strongText,n={strength:`strong`,width:`100%`};break;default:t=this.promptText,n=null}return{label:t,meter:n}},onInvalid:function(e){this.$emit(`invalid`,e)},bindScrollListener:function(){var e=this;this.scrollHandler||=new D(this.$refs.input.$el,function(){e.overlayVisible&&=!1}),this.scrollHandler.bindScrollListener()},unbindScrollListener:function(){this.scrollHandler&&this.scrollHandler.unbindScrollListener()},bindResizeListener:function(){var e=this;this.resizeListener||(this.resizeListener=function(){e.overlayVisible&&!h()&&(e.overlayVisible=!1)},window.addEventListener(`resize`,this.resizeListener))},unbindResizeListener:function(){this.resizeListener&&=(window.removeEventListener(`resize`,this.resizeListener),null)},overlayRef:function(e){this.overlay=e},onMaskToggle:function(){this.unmasked=!this.unmasked},onClearClick:function(e){this.writeValue(null,{})},onOverlayClick:function(e){O.emit(`overlay-click`,{originalEvent:e,target:this.$el})}},computed:{inputType:function(){return this.unmasked?`text`:`password`},weakText:function(){return this.weakLabel||this.$primevue.config.locale.weak},mediumText:function(){return this.mediumLabel||this.$primevue.config.locale.medium},strongText:function(){return this.strongLabel||this.$primevue.config.locale.strong},promptText:function(){return this.promptLabel||this.$primevue.config.locale.passwordPrompt},isClearIconVisible:function(){return this.showClear&&this.$filled&&!this.disabled},overlayUniqueId:function(){return this.$id+`_overlay`},containerDataP:function(){return b({fluid:this.$fluid})},meterDataP:function(){return b(H({},this.meter?.strength,this.meter?.strength))},overlayDataP:function(){return b(H({},`portal-`+this.appendTo,`portal-`+this.appendTo))}},components:{InputText:E,Portal:S,EyeSlashIcon:A,EyeIcon:k,TimesIcon:w}};function K(e){"@babel/helpers - typeof";return K=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},K(e)}function q(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function J(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?q(Object(n),!0).forEach(function(t){Y(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):q(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Y(e,t,n){return(t=X(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function X(e){var t=Z(e,`string`);return K(t)==`symbol`?t:t+``}function Z(e,t){if(K(e)!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t);if(K(r)!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}var Q=[`data-p`],$=[`id`,`data-p`],ee=[`data-p`];function te(e,m,h,g,_,v){var y=n(`InputText`),b=n(`TimesIcon`),x=n(`Portal`);return o(),i(`div`,a({class:e.cx(`root`),style:e.sx(`root`),"data-p":v.containerDataP},e.ptmi(`root`)),[t(y,a({ref:`input`,id:e.inputId,type:v.inputType,class:[e.cx(`pcInputText`),e.inputClass],style:e.inputStyle,defaultValue:e.d_value,name:e.$formName,"aria-labelledby":e.ariaLabelledby,"aria-label":e.ariaLabel,"aria-expanded":_.overlayVisible,"aria-controls":_.overlayVisible?e.overlayProps&&e.overlayProps.id||e.overlayId||e.panelProps&&e.panelProps.id||e.panelId||v.overlayUniqueId:void 0,"aria-haspopup":e.feedback,placeholder:e.placeholder,required:e.required,fluid:e.fluid,disabled:e.disabled,variant:e.variant,invalid:e.invalid,size:e.size,autofocus:e.autofocus,onInput:v.onInput,onFocus:v.onFocus,onBlur:v.onBlur,onKeyup:v.onKeyUp,onInvalid:v.onInvalid},e.inputProps,{"data-p-has-e-icon":e.toggleMask,pt:e.ptm(`pcInputText`),unstyled:e.unstyled}),null,16,`id.type.class.style.defaultValue.name.aria-labelledby.aria-label.aria-expanded.aria-controls.aria-haspopup.placeholder.required.fluid.disabled.variant.invalid.size.autofocus.onInput.onFocus.onBlur.onKeyup.onInvalid.data-p-has-e-icon.pt.unstyled`.split(`.`)),e.toggleMask&&_.unmasked?d(e.$slots,e.$slots.maskicon?`maskicon`:`hideicon`,a({key:0,toggleCallback:v.onMaskToggle,class:[e.cx(`maskIcon`),e.maskIcon]},e.ptm(`maskIcon`)),function(){return[(o(),l(u(e.maskIcon?`i`:`EyeSlashIcon`),a({class:[e.cx(`maskIcon`),e.maskIcon],onClick:v.onMaskToggle},e.ptm(`maskIcon`)),null,16,[`class`,`onClick`]))]}):f(``,!0),e.toggleMask&&!_.unmasked?d(e.$slots,e.$slots.unmaskicon?`unmaskicon`:`showicon`,a({key:1,toggleCallback:v.onMaskToggle,class:[e.cx(`unmaskIcon`)]},e.ptm(`unmaskIcon`)),function(){return[(o(),l(u(e.unmaskIcon?`i`:`EyeIcon`),a({class:[e.cx(`unmaskIcon`),e.unmaskIcon],onClick:v.onMaskToggle},e.ptm(`unmaskIcon`)),null,16,[`class`,`onClick`]))]}):f(``,!0),v.isClearIconVisible?d(e.$slots,`clearicon`,a({key:2,class:e.cx(`clearIcon`),clearCallback:v.onClearClick},e.ptm(`clearIcon`)),function(){return[t(b,a({class:[e.cx(`clearIcon`)],onClick:v.onClearClick},e.ptm(`clearIcon`)),null,16,[`class`,`onClick`])]}):f(``,!0),r(`span`,a({class:`p-hidden-accessible`,"aria-live":`polite`},e.ptm(`hiddenAccesible`),{"data-p-hidden-accessible":!0}),c(_.infoText),17),t(x,{appendTo:e.appendTo},{default:s(function(){return[t(p,a({name:`p-anchored-overlay`,onEnter:v.onOverlayEnter,onLeave:v.onOverlayLeave,onAfterLeave:v.onOverlayAfterLeave},e.ptm(`transition`)),{default:s(function(){return[_.overlayVisible?(o(),i(`div`,a({key:0,ref:v.overlayRef,id:e.overlayId||e.panelId||v.overlayUniqueId,class:[e.cx(`overlay`),e.panelClass,e.overlayClass],style:[e.overlayStyle,e.panelStyle],onClick:m[0]||=function(){return v.onOverlayClick&&v.onOverlayClick.apply(v,arguments)},"data-p":v.overlayDataP,role:`dialog`,"aria-live":`polite`},J(J(J({},e.panelProps),e.overlayProps),e.ptm(`overlay`))),[d(e.$slots,`header`),d(e.$slots,`content`,{},function(){return[r(`div`,a({class:e.cx(`content`)},e.ptm(`content`)),[r(`div`,a({class:e.cx(`meter`)},e.ptm(`meter`)),[r(`div`,a({class:e.cx(`meterLabel`),style:{width:_.meter?_.meter.width:``},"data-p":v.meterDataP},e.ptm(`meterLabel`)),null,16,ee)],16),r(`div`,a({class:e.cx(`meterText`)},e.ptm(`meterText`)),c(_.infoText),17)],16)]}),d(e.$slots,`footer`)],16,$)):f(``,!0)]}),_:3},16,[`onEnter`,`onLeave`,`onAfterLeave`])]}),_:3},8,[`appendTo`])],16,Q)}G.render=te;export{G as n,z as t};