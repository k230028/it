import{n as e}from"./Dd_uD5pT.js";import{Ct as t,D as n,E as r,St as i,Yt as a,Zn as o,_ as s,b as c,bt as l,et as u,mt as d,o as f,qt as p,tr as m,v as h,wt as g,xt as _,y as v}from"./BX3QIp9d.js";import{t as y}from"./BEaavq_b.js";import{B as b,D as x,F as S,P as C,Q as w,St as T,et as E,l as D,t as O}from"./DWv9zje-.js";import{t as k}from"./CRHlWn3X.js";import{t as A}from"./cO8iUN-n.js";import{t as j}from"./D3RJIeFz.js";import{t as M}from"./Bh2RCD2L.js";import{t as N}from"./B5lpRDU02.js";import{t as P}from"./DzmtD0zQ2.js";import{t as F}from"./_s8140ec.js";var I=O.extend({name:`menu`,style:`
    .p-menu {
        background: dt('menu.background');
        color: dt('menu.color');
        border: 1px solid dt('menu.border.color');
        border-radius: dt('menu.border.radius');
        min-width: 12.5rem;
    }

    .p-menu-list {
        margin: 0;
        padding: dt('menu.list.padding');
        outline: 0 none;
        list-style: none;
        display: flex;
        flex-direction: column;
        gap: dt('menu.list.gap');
    }

    .p-menu-item-content {
        transition:
            background dt('menu.transition.duration'),
            color dt('menu.transition.duration');
        border-radius: dt('menu.item.border.radius');
        color: dt('menu.item.color');
        overflow: hidden;
    }

    .p-menu-item-link {
        cursor: pointer;
        display: flex;
        align-items: center;
        text-decoration: none;
        overflow: hidden;
        position: relative;
        color: inherit;
        padding: dt('menu.item.padding');
        gap: dt('menu.item.gap');
        user-select: none;
        outline: 0 none;
    }

    .p-menu-item-label {
        line-height: 1;
    }

    .p-menu-item-icon {
        color: dt('menu.item.icon.color');
    }

    .p-menu-item.p-focus .p-menu-item-content {
        color: dt('menu.item.focus.color');
        background: dt('menu.item.focus.background');
    }

    .p-menu-item.p-focus .p-menu-item-icon {
        color: dt('menu.item.icon.focus.color');
    }

    .p-menu-item:not(.p-disabled) .p-menu-item-content:hover {
        color: dt('menu.item.focus.color');
        background: dt('menu.item.focus.background');
    }

    .p-menu-item:not(.p-disabled) .p-menu-item-content:hover .p-menu-item-icon {
        color: dt('menu.item.icon.focus.color');
    }

    .p-menu-overlay {
        box-shadow: dt('menu.shadow');
    }

    .p-menu-submenu-label {
        background: dt('menu.submenu.label.background');
        padding: dt('menu.submenu.label.padding');
        color: dt('menu.submenu.label.color');
        font-weight: dt('menu.submenu.label.font.weight');
    }

    .p-menu-separator {
        border-block-start: 1px solid dt('menu.separator.border.color');
    }
`,classes:{root:function(e){return[`p-menu p-component`,{"p-menu-overlay":e.props.popup}]},start:`p-menu-start`,list:`p-menu-list`,submenuLabel:`p-menu-submenu-label`,separator:`p-menu-separator`,end:`p-menu-end`,item:function(e){var t=e.instance;return[`p-menu-item`,{"p-focus":t.id===t.focusedOptionId,"p-disabled":t.disabled()}]},itemContent:`p-menu-item-content`,itemLink:`p-menu-item-link`,itemIcon:`p-menu-item-icon`,itemLabel:`p-menu-item-label`}}),L=e({default:()=>Q}),R={name:`BaseMenu`,extends:M,props:{popup:{type:Boolean,default:!1},model:{type:Array,default:null},appendTo:{type:[String,Object],default:`body`},autoZIndex:{type:Boolean,default:!0},baseZIndex:{type:Number,default:0},tabindex:{type:Number,default:0},ariaLabel:{type:String,default:null},ariaLabelledby:{type:String,default:null}},style:I,provide:function(){return{$pcMenu:this,$parentInstance:this}}},z={name:`Menuitem`,hostName:`Menu`,extends:M,inheritAttrs:!1,emits:[`item-click`,`item-mousemove`],props:{item:null,templates:null,id:null,focusedOptionId:null,index:null},methods:{getItemProp:function(e,t){return e&&e.item?T(e.item[t]):void 0},getPTOptions:function(e){return this.ptm(e,{context:{item:this.item,index:this.index,focused:this.isItemFocused(),disabled:this.disabled()}})},isItemFocused:function(){return this.focusedOptionId===this.id},onItemClick:function(e){var t=this.getItemProp(this.item,`command`);t&&t({originalEvent:e,item:this.item.item}),this.$emit(`item-click`,{originalEvent:e,item:this.item,id:this.id})},onItemMouseMove:function(e){this.$emit(`item-mousemove`,{originalEvent:e,item:this.item,id:this.id})},visible:function(){return typeof this.item.visible==`function`?this.item.visible():this.item.visible!==!1},disabled:function(){return typeof this.item.disabled==`function`?this.item.disabled():this.item.disabled},label:function(){return typeof this.item.label==`function`?this.item.label():this.item.label},getMenuItemProps:function(e){return{action:u({class:this.cx(`itemLink`),tabindex:`-1`},this.getPTOptions(`itemLink`)),icon:u({class:[this.cx(`itemIcon`),e.icon]},this.getPTOptions(`itemIcon`)),label:u({class:this.cx(`itemLabel`)},this.getPTOptions(`itemLabel`))}}},computed:{dataP:function(){return k({focus:this.isItemFocused(),disabled:this.disabled()})}},directives:{ripple:N}},B=[`id`,`aria-label`,`aria-disabled`,`data-p-focused`,`data-p-disabled`,`data-p`],V=[`data-p`],H=[`href`,`target`],U=[`data-p`],W=[`data-p`];function G(e,n,r,i,l,f){var p=t(`ripple`);return f.visible()?(d(),c(`li`,u({key:0,id:r.id,class:[e.cx(`item`),r.item.class],role:`menuitem`,style:r.item.style,"aria-label":f.label(),"aria-disabled":f.disabled(),"data-p-focused":f.isItemFocused(),"data-p-disabled":f.disabled()||!1,"data-p":f.dataP},f.getPTOptions(`item`)),[s(`div`,u({class:e.cx(`itemContent`),onClick:n[0]||=function(e){return f.onItemClick(e)},onMousemove:n[1]||=function(e){return f.onItemMouseMove(e)},"data-p":f.dataP},f.getPTOptions(`itemContent`)),[r.templates.item?r.templates.item?(d(),h(g(r.templates.item),{key:1,item:r.item,label:f.label(),props:f.getMenuItemProps(r.item)},null,8,[`item`,`label`,`props`])):v(``,!0):a((d(),c(`a`,u({key:0,href:r.item.url,class:e.cx(`itemLink`),target:r.item.target,tabindex:`-1`},f.getPTOptions(`itemLink`)),[r.templates.itemicon?(d(),h(g(r.templates.itemicon),{key:0,item:r.item,class:o(e.cx(`itemIcon`))},null,8,[`item`,`class`])):r.item.icon?(d(),c(`span`,u({key:1,class:[e.cx(`itemIcon`),r.item.icon],"data-p":f.dataP},f.getPTOptions(`itemIcon`)),null,16,U)):v(``,!0),s(`span`,u({class:e.cx(`itemLabel`),"data-p":f.dataP},f.getPTOptions(`itemLabel`)),m(f.label()),17,W)],16,H)),[[p]])],16,V)],16,B)):v(``,!0)}z.render=G;function K(e){return X(e)||Y(e)||J(e)||q()}function q(){throw TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function J(e,t){if(e){if(typeof e==`string`)return Z(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?Z(e,t):void 0}}function Y(e){if(typeof Symbol<`u`&&e[Symbol.iterator]!=null||e[`@@iterator`]!=null)return Array.from(e)}function X(e){if(Array.isArray(e))return Z(e)}function Z(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}var Q={name:`Menu`,extends:R,inheritAttrs:!1,emits:[`show`,`hide`,`focus`,`blur`],data:function(){return{overlayVisible:!1,focused:!1,focusedOptionIndex:-1,selectedOptionIndex:-1}},target:null,outsideClickListener:null,scrollHandler:null,resizeListener:null,container:null,list:null,mounted:function(){this.popup||(this.bindResizeListener(),this.bindOutsideClickListener())},beforeUnmount:function(){this.unbindResizeListener(),this.unbindOutsideClickListener(),this.scrollHandler&&=(this.scrollHandler.destroy(),null),this.target=null,this.container&&this.autoZIndex&&A.clear(this.container),this.container=null},methods:{itemClick:function(e){var t=e.item;this.disabled(t)||(t.command&&t.command(e),this.overlayVisible&&this.hide(),!this.popup&&this.focusedOptionIndex!==e.id&&(this.focusedOptionIndex=e.id))},itemMouseMove:function(e){this.focused&&(this.focusedOptionIndex=e.id)},onListFocus:function(e){this.focused=!0,!this.popup&&this.changeFocusedOptionIndex(0),this.$emit(`focus`,e)},onListBlur:function(e){this.focused=!1,this.focusedOptionIndex=-1,this.$emit(`blur`,e)},onListKeyDown:function(e){switch(e.code){case`ArrowDown`:this.onArrowDownKey(e);break;case`ArrowUp`:this.onArrowUpKey(e);break;case`Home`:this.onHomeKey(e);break;case`End`:this.onEndKey(e);break;case`Enter`:case`NumpadEnter`:this.onEnterKey(e);break;case`Space`:this.onSpaceKey(e);break;case`Escape`:this.popup&&(b(this.target),this.hide());case`Tab`:this.overlayVisible&&this.hide()}},onArrowDownKey:function(e){var t=this.findNextOptionIndex(this.focusedOptionIndex);this.changeFocusedOptionIndex(t),e.preventDefault()},onArrowUpKey:function(e){if(e.altKey&&this.popup)b(this.target),this.hide(),e.preventDefault();else{var t=this.findPrevOptionIndex(this.focusedOptionIndex);this.changeFocusedOptionIndex(t),e.preventDefault()}},onHomeKey:function(e){this.changeFocusedOptionIndex(0),e.preventDefault()},onEndKey:function(e){this.changeFocusedOptionIndex(C(this.container,`li[data-pc-section="item"][data-p-disabled="false"]`).length-1),e.preventDefault()},onEnterKey:function(e){var t=E(this.list,`li[id="${`${this.focusedOptionIndex}`}"]`),n=t&&E(t,`a[data-pc-section="itemlink"]`);this.popup&&b(this.target),n?n.click():t&&t.click(),e.preventDefault()},onSpaceKey:function(e){this.onEnterKey(e)},findNextOptionIndex:function(e){var t=K(C(this.container,`li[data-pc-section="item"][data-p-disabled="false"]`)).findIndex(function(t){return t.id===e});return t>-1?t+1:0},findPrevOptionIndex:function(e){var t=K(C(this.container,`li[data-pc-section="item"][data-p-disabled="false"]`)).findIndex(function(t){return t.id===e});return t>-1?t-1:0},changeFocusedOptionIndex:function(e){var t=C(this.container,`li[data-pc-section="item"][data-p-disabled="false"]`),n=e>=t.length?t.length-1:e<0?0:e;n>-1&&(this.focusedOptionIndex=t[n].getAttribute(`id`))},toggle:function(e,t){this.overlayVisible?this.hide():this.show(e,t)},show:function(e,t){this.overlayVisible=!0,this.target=t??e.currentTarget},hide:function(){this.overlayVisible=!1,this.target=null},onEnter:function(e){x(e,{position:`absolute`,top:`0`}),this.alignOverlay(),this.bindOutsideClickListener(),this.bindResizeListener(),this.bindScrollListener(),this.autoZIndex&&A.set(`menu`,e,this.baseZIndex||this.$primevue.config.zIndex.menu),this.popup&&b(this.list),this.$emit(`show`)},onLeave:function(){this.unbindOutsideClickListener(),this.unbindResizeListener(),this.unbindScrollListener(),this.$emit(`hide`)},onAfterLeave:function(e){this.autoZIndex&&A.clear(e)},alignOverlay:function(){D(this.container,this.target),w(this.target)>w(this.container)&&(this.container.style.minWidth=w(this.target)+`px`)},bindOutsideClickListener:function(){var e=this;this.outsideClickListener||(this.outsideClickListener=function(t){var n=e.container&&!e.container.contains(t.target),r=!(e.target&&(e.target===t.target||e.target.contains(t.target)));e.overlayVisible&&n&&r?e.hide():!e.popup&&n&&r&&(e.focusedOptionIndex=-1)},document.addEventListener(`click`,this.outsideClickListener,!0))},unbindOutsideClickListener:function(){this.outsideClickListener&&=(document.removeEventListener(`click`,this.outsideClickListener,!0),null)},bindScrollListener:function(){var e=this;this.scrollHandler||=new P(this.target,function(){e.overlayVisible&&e.hide()}),this.scrollHandler.bindScrollListener()},unbindScrollListener:function(){this.scrollHandler&&this.scrollHandler.unbindScrollListener()},bindResizeListener:function(){var e=this;this.resizeListener||(this.resizeListener=function(){e.overlayVisible&&!S()&&e.hide()},window.addEventListener(`resize`,this.resizeListener))},unbindResizeListener:function(){this.resizeListener&&=(window.removeEventListener(`resize`,this.resizeListener),null)},visible:function(e){return typeof e.visible==`function`?e.visible():e.visible!==!1},disabled:function(e){return typeof e.disabled==`function`?e.disabled():e.disabled},label:function(e){return typeof e.label==`function`?e.label():e.label},onOverlayClick:function(e){F.emit(`overlay-click`,{originalEvent:e,target:this.target})},containerRef:function(e){this.container=e},listRef:function(e){this.list=e}},computed:{focusedOptionId:function(){return this.focusedOptionIndex===-1?null:this.focusedOptionIndex},dataP:function(){return k({popup:this.popup})}},components:{PVMenuitem:z,Portal:j}},$=[`id`,`data-p`],ee=[`id`,`tabindex`,`aria-activedescendant`,`aria-label`,`aria-labelledby`],te=[`id`];function ne(e,t,a,o,g,b){var x=i(`PVMenuitem`),S=i(`Portal`);return d(),h(S,{appendTo:e.appendTo,disabled:!e.popup},{default:p(function(){return[n(y,u({name:`p-anchored-overlay`,onEnter:b.onEnter,onLeave:b.onLeave,onAfterLeave:b.onAfterLeave},e.ptm(`transition`)),{default:p(function(){return[!e.popup||g.overlayVisible?(d(),c(`div`,u({key:0,ref:b.containerRef,id:e.$id,class:e.cx(`root`),onClick:t[3]||=function(){return b.onOverlayClick&&b.onOverlayClick.apply(b,arguments)},"data-p":b.dataP},e.ptmi(`root`)),[e.$slots.start?(d(),c(`div`,u({key:0,class:e.cx(`start`)},e.ptm(`start`)),[_(e.$slots,`start`)],16)):v(``,!0),s(`ul`,u({ref:b.listRef,id:e.$id+`_list`,class:e.cx(`list`),role:`menu`,tabindex:e.tabindex,"aria-activedescendant":g.focused?b.focusedOptionId:void 0,"aria-label":e.ariaLabel,"aria-labelledby":e.ariaLabelledby,onFocus:t[0]||=function(){return b.onListFocus&&b.onListFocus.apply(b,arguments)},onBlur:t[1]||=function(){return b.onListBlur&&b.onListBlur.apply(b,arguments)},onKeydown:t[2]||=function(){return b.onListKeyDown&&b.onListKeyDown.apply(b,arguments)}},e.ptm(`list`)),[(d(!0),c(f,null,l(e.model,function(t,n){return d(),c(f,{key:b.label(t)+n.toString()},[t.items&&b.visible(t)&&!t.separator?(d(),c(f,{key:0},[t.items?(d(),c(`li`,u({key:0,id:e.$id+`_`+n,class:[e.cx(`submenuLabel`),t.class],role:`none`},{ref_for:!0},e.ptm(`submenuLabel`)),[_(e.$slots,e.$slots.submenulabel?`submenulabel`:`submenuheader`,{item:t},function(){return[r(m(b.label(t)),1)]})],16,te)):v(``,!0),(d(!0),c(f,null,l(t.items,function(r,i){return d(),c(f,{key:r.label+n+`_`+i},[b.visible(r)&&!r.separator?(d(),h(x,{key:0,id:e.$id+`_`+n+`_`+i,item:r,templates:e.$slots,focusedOptionId:b.focusedOptionId,unstyled:e.unstyled,onItemClick:b.itemClick,onItemMousemove:b.itemMouseMove,pt:e.pt},null,8,[`id`,`item`,`templates`,`focusedOptionId`,`unstyled`,`onItemClick`,`onItemMousemove`,`pt`])):b.visible(r)&&r.separator?(d(),c(`li`,u({key:`separator`+n+i,class:[e.cx(`separator`),t.class],style:r.style,role:`separator`},{ref_for:!0},e.ptm(`separator`)),null,16)):v(``,!0)],64)}),128))],64)):b.visible(t)&&t.separator?(d(),c(`li`,u({key:`separator`+n.toString(),class:[e.cx(`separator`),t.class],style:t.style,role:`separator`},{ref_for:!0},e.ptm(`separator`)),null,16)):(d(),h(x,{key:b.label(t)+n.toString(),id:e.$id+`_`+n,item:t,index:n,templates:e.$slots,focusedOptionId:b.focusedOptionId,unstyled:e.unstyled,onItemClick:b.itemClick,onItemMousemove:b.itemMouseMove,pt:e.pt},null,8,[`id`,`item`,`index`,`templates`,`focusedOptionId`,`unstyled`,`onItemClick`,`onItemMousemove`,`pt`]))],64)}),128))],16,ee),e.$slots.end?(d(),c(`div`,u({key:1,class:e.cx(`end`)},e.ptm(`end`)),[_(e.$slots,`end`)],16)):v(``,!0)],16,$)):v(``,!0)]}),_:3},16,[`onEnter`,`onLeave`,`onAfterLeave`])]}),_:3},8,[`appendTo`,`disabled`])}Q.render=ne;export{Q as n,L as t};