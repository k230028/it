import{n as e}from"./Dd_uD5pT.js";import{D as t,St as n,Zn as r,_ as i,b as a,bt as o,et as s,mt as c,o as l,tr as u,v as d,wt as f,xt as p,y as m}from"./BX3QIp9d.js";import{t as h}from"./DWv9zje-.js";import{t as g}from"./Bh2RCD2L.js";import{t as _}from"./DVId6gjh2.js";var v=h.extend({name:`breadcrumb`,style:`
    .p-breadcrumb {
        background: dt('breadcrumb.background');
        padding: dt('breadcrumb.padding');
        overflow-x: auto;
    }

    .p-breadcrumb-list {
        margin: 0;
        padding: 0;
        list-style-type: none;
        display: flex;
        align-items: center;
        flex-wrap: nowrap;
        gap: dt('breadcrumb.gap');
    }

    .p-breadcrumb-separator {
        display: flex;
        align-items: center;
        color: dt('breadcrumb.separator.color');
    }

    .p-breadcrumb-separator-icon:dir(rtl) {
        transform: rotate(180deg);
    }

    .p-breadcrumb::-webkit-scrollbar {
        display: none;
    }

    .p-breadcrumb-item-link {
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: dt('breadcrumb.item.gap');
        transition:
            background dt('breadcrumb.transition.duration'),
            color dt('breadcrumb.transition.duration'),
            outline-color dt('breadcrumb.transition.duration'),
            box-shadow dt('breadcrumb.transition.duration');
        border-radius: dt('breadcrumb.item.border.radius');
        outline-color: transparent;
        color: dt('breadcrumb.item.color');
    }

    .p-breadcrumb-item-link:focus-visible {
        box-shadow: dt('breadcrumb.item.focus.ring.shadow');
        outline: dt('breadcrumb.item.focus.ring.width') dt('breadcrumb.item.focus.ring.style') dt('breadcrumb.item.focus.ring.color');
        outline-offset: dt('breadcrumb.item.focus.ring.offset');
    }

    .p-breadcrumb-item-link:hover .p-breadcrumb-item-label {
        color: dt('breadcrumb.item.hover.color');
    }

    .p-breadcrumb-item-label {
        transition: inherit;
    }

    .p-breadcrumb-item-icon {
        color: dt('breadcrumb.item.icon.color');
        transition: inherit;
    }

    .p-breadcrumb-item-link:hover .p-breadcrumb-item-icon {
        color: dt('breadcrumb.item.icon.hover.color');
    }
`,classes:{root:`p-breadcrumb p-component`,list:`p-breadcrumb-list`,homeItem:`p-breadcrumb-home-item`,separator:`p-breadcrumb-separator`,separatorIcon:`p-breadcrumb-separator-icon`,item:function(e){return[`p-breadcrumb-item`,{"p-disabled":e.instance.disabled()}]},itemLink:`p-breadcrumb-item-link`,itemIcon:`p-breadcrumb-item-icon`,itemLabel:`p-breadcrumb-item-label`}}),y=e({default:()=>w}),b={name:`BaseBreadcrumb`,extends:g,props:{model:{type:Array,default:null},home:{type:null,default:null}},style:v,provide:function(){return{$pcBreadcrumb:this,$parentInstance:this}}},x={name:`BreadcrumbItem`,hostName:`Breadcrumb`,extends:g,props:{item:null,templates:null,index:null},methods:{onClick:function(e){this.item.command&&this.item.command({originalEvent:e,item:this.item})},visible:function(){return typeof this.item.visible==`function`?this.item.visible():this.item.visible!==!1},disabled:function(){return typeof this.item.disabled==`function`?this.item.disabled():this.item.disabled},label:function(){return typeof this.item.label==`function`?this.item.label():this.item.label},isCurrentUrl:function(){var e=this.item,t=e.to,n=e.url,r=typeof window<`u`?window.location.pathname:``;return t===r||n===r?`page`:void 0}},computed:{ptmOptions:function(){return{context:{item:this.item,index:this.index}}},getMenuItemProps:function(){var e=this;return{action:s({class:this.cx(`itemLink`),"aria-current":this.isCurrentUrl(),onClick:function(t){return e.onClick(t)}},this.ptm(`itemLink`,this.ptmOptions)),icon:s({class:[this.cx(`icon`),this.item.icon]},this.ptm(`icon`,this.ptmOptions)),label:s({class:this.cx(`label`)},this.ptm(`label`,this.ptmOptions))}}}},S=[`href`,`target`,`aria-current`];function C(e,t,n,i,o,l){return l.visible()?(c(),a(`li`,s({key:0,class:[e.cx(`item`),n.item.class]},e.ptm(`item`,l.ptmOptions)),[n.templates.item?(c(),d(f(n.templates.item),{key:1,item:n.item,label:l.label(),props:l.getMenuItemProps},null,8,[`item`,`label`,`props`])):(c(),a(`a`,s({key:0,href:n.item.url||`#`,class:e.cx(`itemLink`),target:n.item.target,"aria-current":l.isCurrentUrl(),onClick:t[0]||=function(){return l.onClick&&l.onClick.apply(l,arguments)}},e.ptm(`itemLink`,l.ptmOptions)),[n.templates&&n.templates.itemicon?(c(),d(f(n.templates.itemicon),{key:0,item:n.item,class:r(e.cx(`itemIcon`,l.ptmOptions))},null,8,[`item`,`class`])):n.item.icon?(c(),a(`span`,s({key:1,class:[e.cx(`itemIcon`),n.item.icon]},e.ptm(`itemIcon`,l.ptmOptions)),null,16)):m(``,!0),n.item.label?(c(),a(`span`,s({key:2,class:e.cx(`itemLabel`)},e.ptm(`itemLabel`,l.ptmOptions)),u(l.label()),17)):m(``,!0)],16,S))],16)):m(``,!0)}x.render=C;var w={name:`Breadcrumb`,extends:b,inheritAttrs:!1,components:{BreadcrumbItem:x,ChevronRightIcon:_}};function T(e,r,u,f,h,g){var _=n(`BreadcrumbItem`),v=n(`ChevronRightIcon`);return c(),a(`nav`,s({class:e.cx(`root`)},e.ptmi(`root`)),[i(`ol`,s({class:e.cx(`list`)},e.ptm(`list`)),[e.home?(c(),d(_,s({key:0,item:e.home,class:e.cx(`homeItem`),templates:e.$slots,pt:e.pt,unstyled:e.unstyled},e.ptm(`homeItem`)),null,16,[`item`,`class`,`templates`,`pt`,`unstyled`])):m(``,!0),(c(!0),a(l,null,o(e.model,function(n,r){return c(),a(l,{key:n.label+`_`+r},[e.home||r!==0?(c(),a(`li`,s({key:0,class:e.cx(`separator`)},{ref_for:!0},e.ptm(`separator`)),[p(e.$slots,`separator`,{},function(){return[t(v,s({"aria-hidden":`true`,class:e.cx(`separatorIcon`)},{ref_for:!0},e.ptm(`separatorIcon`)),null,16,[`class`])]})],16)):m(``,!0),t(_,{item:n,index:r,templates:e.$slots,pt:e.pt,unstyled:e.unstyled},null,8,[`item`,`index`,`templates`,`pt`,`unstyled`])],64)}),128))],16)],16)}w.render=T;export{w as n,y as t};