import{n as e}from"./Dd_uD5pT.js";import{E as t,St as n,_ as r,b as i,bt as a,et as o,mt as s,o as c,qt as l,tr as u,v as d,wt as f,xt as p,y as m}from"./BX3QIp9d.js";import{C as h,L as g,M as _,P as v,et as y,ft as b,gt as x,t as S,w as C}from"./DWv9zje-.js";import{t as w}from"./Bh2RCD2L.js";import{t as T}from"./B5lpRDU02.js";import{n as E}from"./Cu-q4Ecl2.js";import{t as D}from"./DVId6gjh2.js";import{t as O}from"./DAL9K5f12.js";import{t as k}from"./BrMKvuT52.js";import{t as A}from"./D1Z6SBIc.js";var j=S.extend({name:`carousel`,style:`
    .p-carousel {
        display: flex;
        flex-direction: column;
    }

    .p-carousel-content-container {
        display: flex;
        flex-direction: column;
        overflow: auto;
    }

    .p-carousel-content {
        display: flex;
        flex-direction: row;
        gap: dt('carousel.content.gap');
    }

    .p-carousel-content:dir(rtl) {
        flex-direction: row-reverse;
    }

    .p-carousel-viewport {
        overflow: hidden;
        width: 100%;
    }

    .p-carousel-item-list {
        display: flex;
        flex-direction: row;
    }

    .p-carousel-item-list:dir(rtl) {
        flex-direction: row-reverse;
    }

    .p-carousel-prev-button,
    .p-carousel-next-button {
        align-self: center;
        flex-shrink: 0;
    }

    .p-carousel-indicator-list {
        display: flex;
        flex-direction: row;
        justify-content: center;
        flex-wrap: wrap;
        padding: dt('carousel.indicator.list.padding');
        gap: dt('carousel.indicator.list.gap');
        margin: 0;
        list-style: none;
    }

    .p-carousel-indicator-button {
        display: flex;
        align-items: center;
        justify-content: center;
        background: dt('carousel.indicator.background');
        width: dt('carousel.indicator.width');
        height: dt('carousel.indicator.height');
        border: 0 none;
        transition:
            background dt('carousel.transition.duration'),
            color dt('carousel.transition.duration'),
            outline-color dt('carousel.transition.duration'),
            box-shadow dt('carousel.transition.duration');
        outline-color: transparent;
        border-radius: dt('carousel.indicator.border.radius');
        padding: 0;
        margin: 0;
        user-select: none;
        cursor: pointer;
    }

    .p-carousel-indicator-button:focus-visible {
        box-shadow: dt('carousel.indicator.focus.ring.shadow');
        outline: dt('carousel.indicator.focus.ring.width') dt('carousel.indicator.focus.ring.style') dt('carousel.indicator.focus.ring.color');
        outline-offset: dt('carousel.indicator.focus.ring.offset');
    }

    .p-carousel-indicator-button:hover {
        background: dt('carousel.indicator.hover.background');
    }

    .p-carousel-indicator-active .p-carousel-indicator-button {
        background: dt('carousel.indicator.active.background');
    }

    .p-carousel-vertical .p-carousel-content {
        flex-direction: column;
    }

    .p-carousel-vertical .p-carousel-item-list {
        flex-direction: column;
        height: 100%;
    }

    .p-items-hidden .p-carousel-item {
        visibility: hidden;
    }

    .p-items-hidden .p-carousel-item.p-carousel-item-active {
        visibility: visible;
    }
`,classes:{root:function(e){var t=e.instance;return[`p-carousel p-component`,{"p-carousel-vertical":t.isVertical(),"p-carousel-horizontal":!t.isVertical()}]},header:`p-carousel-header`,contentContainer:`p-carousel-content-container`,content:`p-carousel-content`,pcPrevButton:function(e){return[`p-carousel-prev-button`,{"p-disabled":e.instance.backwardIsDisabled}]},viewport:`p-carousel-viewport`,itemList:`p-carousel-item-list`,itemClone:function(e){var t=e.index,n=e.value,r=e.totalShiftedItems,i=e.d_numVisible;return[`p-carousel-item p-carousel-item-clone`,{"p-carousel-item-active":r*-1===n.length+i,"p-carousel-item-start":t===0,"p-carousel-item-end":n.slice(-1*i).length-1===t}]},item:function(e){var t=e.instance,n=e.index;return[`p-carousel-item`,{"p-carousel-item-active":t.firstIndex()<=n&&t.lastIndex()>=n,"p-carousel-item-start":t.firstIndex()===n,"p-carousel-item-end":t.lastIndex()===n}]},pcNextButton:function(e){return[`p-carousel-next-button`,{"p-disabled":e.instance.forwardIsDisabled}]},indicatorList:`p-carousel-indicator-list`,indicator:function(e){var t=e.instance,n=e.index;return[`p-carousel-indicator`,{"p-carousel-indicator-active":t.d_page===n}]},indicatorButton:`p-carousel-indicator-button`,footer:`p-carousel-footer`}}),M=e({default:()=>B}),N={name:`BaseCarousel`,extends:w,props:{value:null,page:{type:Number,default:0},numVisible:{type:Number,default:1},numScroll:{type:Number,default:1},responsiveOptions:Array,orientation:{type:String,default:`horizontal`},verticalViewPortHeight:{type:String,default:`300px`},contentClass:String,containerClass:String,indicatorsContentClass:String,circular:{type:Boolean,default:!1},autoplayInterval:{type:Number,default:0},showNavigators:{type:Boolean,default:!0},showIndicators:{type:Boolean,default:!0},prevButtonProps:{type:Object,default:function(){return{severity:`secondary`,text:!0,rounded:!0}}},nextButtonProps:{type:Object,default:function(){return{severity:`secondary`,text:!0,rounded:!0}}}},style:j,provide:function(){return{$pcCarousel:this,$parentInstance:this}}};function P(e){return R(e)||L(e)||I(e)||F()}function F(){throw TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function I(e,t){if(e){if(typeof e==`string`)return z(e,t);var n={}.toString.call(e).slice(8,-1);return n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`?Array.from(e):n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?z(e,t):void 0}}function L(e){if(typeof Symbol<`u`&&e[Symbol.iterator]!=null||e[`@@iterator`]!=null)return Array.from(e)}function R(e){if(Array.isArray(e))return z(e)}function z(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}var B={name:`Carousel`,extends:N,inheritAttrs:!1,emits:[`update:page`],isRemainingItemsAdded:!1,data:function(){return{remainingItems:0,d_numVisible:this.numVisible,d_numScroll:this.numScroll,d_oldNumScroll:0,d_oldNumVisible:0,d_oldValue:null,d_page:this.page,totalShiftedItems:this.page*this.numScroll*-1,allowAutoplay:!!this.autoplayInterval,d_circular:this.circular||this.allowAutoplay,swipeThreshold:20}},watch:{page:function(e){e>this.d_page?this.navForward({},e):e<this.d_page&&this.navBackward({},e),this.d_page=e},circular:function(e){this.d_circular=e},numVisible:function(e,t){this.d_numVisible=e,this.d_oldNumVisible=t},numScroll:function(e,t){this.d_oldNumScroll=t,this.d_numScroll=e},value:function(e){this.d_oldValue=e}},mounted:function(){var e=!1;if(this.createStyle(),this.calculatePosition(),this.responsiveOptions&&this.bindDocumentListeners(),this.isCircular()){var t=this.totalShiftedItems;this.d_page===0?t=-1*this.d_numVisible:t===0&&(t=-1*this.value.length,this.remainingItems>0&&(this.isRemainingItemsAdded=!0)),t!==this.totalShiftedItems&&(this.totalShiftedItems=t,e=!0)}!e&&this.isAutoplay()&&this.startAutoplay()},updated:function(){if(!this.empty){var e=this.isCircular(),t=!1,n=this.totalShiftedItems;if(this.autoplayInterval&&this.stopAutoplay(),this.d_oldNumScroll!==this.d_numScroll||this.d_oldNumVisible!==this.d_numVisible||this.d_oldValue.length!==this.value.length){this.remainingItems=(this.value.length-this.d_numVisible)%this.d_numScroll;var r=this.d_page;this.totalIndicators!==0&&r>=this.totalIndicators&&(r=this.totalIndicators-1,this.$emit(`update:page`,r),this.d_page=r,t=!0),n=r*this.d_numScroll*-1,e&&(n-=this.d_numVisible),r===this.totalIndicators-1&&this.remainingItems>0?(n+=-1*this.remainingItems+this.d_numScroll,this.isRemainingItemsAdded=!0):this.isRemainingItemsAdded=!1,n!==this.totalShiftedItems&&(this.totalShiftedItems=n,t=!0),this.d_oldNumScroll=this.d_numScroll,this.d_oldNumVisible=this.d_numVisible,this.d_oldValue=this.value,this.$refs.itemsContainer.style.transform=this.isVertical()?`translate3d(0, ${n*(100/this.d_numVisible)}%, 0)`:`translate3d(${n*(100/this.d_numVisible)}%, 0, 0)`}e&&(this.d_page===0?n=-1*this.d_numVisible:n===0&&(n=-1*this.value.length,this.remainingItems>0&&(this.isRemainingItemsAdded=!0)),n!==this.totalShiftedItems&&(this.totalShiftedItems=n,t=!0)),!t&&this.isAutoplay()&&this.startAutoplay()}},beforeUnmount:function(){this.responsiveOptions&&this.unbindDocumentListeners(),this.autoplayInterval&&this.stopAutoplay()},methods:{getIndicatorPTOptions:function(e,t){return this.ptm(e,{context:{highlighted:t===this.d_page}})},getItemPTOptions:function(e,t){return this.ptm(e,{context:{index:t,active:this.firstIndex()<=t&&this.lastIndex()>=t,start:this.firstIndex()===t,end:this.lastIndex()===t}})},step:function(e,t){var n=this.totalShiftedItems,r=this.isCircular();if(t!=null)n=this.d_numScroll*t*-1,r&&(n-=this.d_numVisible),this.isRemainingItemsAdded=!1;else{n+=this.d_numScroll*e,this.isRemainingItemsAdded&&=(n+=this.remainingItems-this.d_numScroll*e,!1);var i=r?n+this.d_numVisible:n;t=Math.abs(Math.floor(i/this.d_numScroll))}r&&this.d_page===this.totalIndicators-1&&e===-1?(n=-1*(this.value.length+this.d_numVisible),t=0):r&&this.d_page===0&&e===1?(n=0,t=this.totalIndicators-1):t===this.totalIndicators-1&&this.remainingItems>0&&(n+=this.remainingItems*-1-this.d_numScroll*e,this.isRemainingItemsAdded=!0),this.$refs.itemsContainer&&(!this.isUnstyled&&h(this.$refs.itemsContainer,`p-items-hidden`),this.$refs.itemsContainer.style.transform=this.isVertical()?`translate3d(0, ${n*(100/this.d_numVisible)}%, 0)`:`translate3d(${n*(100/this.d_numVisible)}%, 0, 0)`,this.$refs.itemsContainer.style.transition=`transform 500ms ease 0s`),this.totalShiftedItems=n,this.$emit(`update:page`,t),this.d_page=t},calculatePosition:function(){if(this.$refs.itemsContainer&&this.responsiveOptions){for(var e=window.innerWidth,t={numVisible:this.numVisible,numScroll:this.numScroll},n=0;n<this.responsiveOptions.length;n++){var r=this.responsiveOptions[n];parseInt(r.breakpoint,10)>=e&&(t=r)}if(this.d_numScroll!==t.numScroll){var i=this.d_page;i=parseInt(i*this.d_numScroll/t.numScroll),this.totalShiftedItems=t.numScroll*i*-1,this.isCircular()&&(this.totalShiftedItems-=t.numVisible),this.d_numScroll=t.numScroll,this.$emit(`update:page`,i),this.d_page=i}this.d_numVisible!==t.numVisible&&(this.d_numVisible=t.numVisible)}},navBackward:function(e,t){(this.d_circular||this.d_page!==0)&&this.step(1,t),this.allowAutoplay=!1,e.cancelable&&e.preventDefault()},navForward:function(e,t){(this.d_circular||this.d_page<this.totalIndicators-1)&&this.step(-1,t),this.allowAutoplay=!1,e.cancelable&&e.preventDefault()},onIndicatorClick:function(e,t){var n=this.d_page;t>n?this.navForward(e,t):t<n&&this.navBackward(e,t)},onTransitionEnd:function(){this.$refs.itemsContainer&&(!this.isUnstyled&&_(this.$refs.itemsContainer,`p-items-hidden`),this.$refs.itemsContainer.style.transition=``,(this.d_page===0||this.d_page===this.totalIndicators-1)&&this.isCircular()&&(this.$refs.itemsContainer.style.transform=this.isVertical()?`translate3d(0, ${this.totalShiftedItems*(100/this.d_numVisible)}%, 0)`:`translate3d(${this.totalShiftedItems*(100/this.d_numVisible)}%, 0, 0)`))},onTouchStart:function(e){var t=e.changedTouches[0];this.startPos={x:t.pageX,y:t.pageY}},onTouchMove:function(e){var t=e.changedTouches[0],n=this.isVertical()?t.pageY-this.startPos.y:t.pageX-this.startPos.x;Math.abs(n)>this.swipeThreshold&&e.cancelable&&e.preventDefault()},onTouchEnd:function(e){var t=e.changedTouches[0];this.isVertical()?this.changePageOnTouch(e,t.pageY-this.startPos.y):this.changePageOnTouch(e,t.pageX-this.startPos.x)},changePageOnTouch:function(e,t){Math.abs(t)>this.swipeThreshold&&(t<0?this.navForward(e):this.navBackward(e))},onIndicatorKeydown:function(e){switch(e.code){case`ArrowRight`:this.onRightKey();break;case`ArrowLeft`:this.onLeftKey();break;case`Home`:this.onHomeKey(),e.preventDefault();break;case`End`:this.onEndKey(),e.preventDefault();break;case`ArrowUp`:case`ArrowDown`:case`PageUp`:case`PageDown`:e.preventDefault();break;case`Tab`:this.onTabKey()}},onRightKey:function(){var e=P(v(this.$refs.indicatorContent,`[data-pc-section="indicator"]`)),t=this.findFocusedIndicatorIndex();this.changedFocusedIndicator(t,t+1===e.length?e.length-1:t+1)},onLeftKey:function(){var e=this.findFocusedIndicatorIndex();this.changedFocusedIndicator(e,e-1<=0?0:e-1)},onHomeKey:function(){var e=this.findFocusedIndicatorIndex();this.changedFocusedIndicator(e,0)},onEndKey:function(){var e=P(v(this.$refs.indicatorContent,`[data-pc-section="indicator"]`)),t=this.findFocusedIndicatorIndex();this.changedFocusedIndicator(t,e.length-1)},onTabKey:function(){var e=P(v(this.$refs.indicatorContent,`[data-pc-section="indicator"]`)),t=e.findIndex(function(e){return C(e,`data-p-active`)===!0}),n=y(this.$refs.indicatorContent,`[data-pc-section="indicator"] > button[tabindex="0"]`),r=e.findIndex(function(e){return e===n.parentElement});e[r].children[0].tabIndex=`-1`,e[t].children[0].tabIndex=`0`},findFocusedIndicatorIndex:function(){var e=P(v(this.$refs.indicatorContent,`[data-pc-section="indicator"]`)),t=y(this.$refs.indicatorContent,`[data-pc-section="indicator"] > button[tabindex="0"]`);return e.findIndex(function(e){return e===t.parentElement})},changedFocusedIndicator:function(e,t){var n=P(v(this.$refs.indicatorContent,`[data-pc-section="indicator"]`));n[e].children[0].tabIndex=`-1`,n[t].children[0].tabIndex=`0`,n[t].children[0].focus()},bindDocumentListeners:function(){var e=this;this.documentResizeListener||(this.documentResizeListener=function(t){e.calculatePosition(t)},window.addEventListener(`resize`,this.documentResizeListener))},unbindDocumentListeners:function(){this.documentResizeListener&&=(window.removeEventListener(`resize`,this.documentResizeListener),null)},startAutoplay:function(){var e=this;this.interval=setInterval(function(){e.d_page===e.totalIndicators-1?e.step(-1,0):e.step(-1,e.d_page+1)},this.autoplayInterval)},stopAutoplay:function(){this.interval&&clearInterval(this.interval)},createStyle:function(){if(!this.carouselStyle){var e;this.carouselStyle=document.createElement(`style`),this.carouselStyle.type=`text/css`,g(this.carouselStyle,`nonce`,(e=this.$primevue)==null||(e=e.config)==null||(e=e.csp)==null?void 0:e.nonce),document.body.appendChild(this.carouselStyle)}var t=`
                .p-carousel[${this.$attrSelector}] .p-carousel-item {
                    flex: 1 0 ${100/this.d_numVisible}%
                }
            `;if(this.responsiveOptions&&!this.isUnstyled){var n=P(this.responsiveOptions),r=b();n.sort(function(e,t){var n=e.breakpoint,i=t.breakpoint;return x(n,i,-1,r)});for(var i=0;i<n.length;i++){var a=n[i];t+=`
                        @media screen and (max-width: ${a.breakpoint}) {
                            .p-carousel[${this.$attrSelector}] .p-carousel-item {
                                flex: 1 0 ${100/a.numVisible}%
                            }
                        }
                    `}}this.carouselStyle.innerHTML=t},isVertical:function(){return this.orientation===`vertical`},hasValidItemCount:function(){return this.value&&this.value.length>this.d_numVisible},isCircular:function(){return this.hasValidItemCount()&&this.d_circular},isAutoplay:function(){return this.hasValidItemCount()&&this.autoplayInterval&&this.allowAutoplay},firstIndex:function(){return this.isCircular()?-1*(this.totalShiftedItems+this.d_numVisible):this.totalShiftedItems*-1},lastIndex:function(){return this.firstIndex()+this.d_numVisible-1},ariaSlideNumber:function(e){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.slideNumber.replace(/{slideNumber}/g,e):void 0},ariaPageLabel:function(e){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.pageLabel.replace(/{page}/g,e):void 0}},computed:{totalIndicators:function(){return this.value?Math.max(Math.ceil((this.value.length-this.d_numVisible)/this.d_numScroll)+1,0):0},backwardIsDisabled:function(){return this.value&&(!this.circular||this.value.length<this.d_numVisible)&&this.d_page===0},forwardIsDisabled:function(){return this.value&&(!this.circular||this.value.length<this.d_numVisible)&&(this.d_page===this.totalIndicators-1||this.totalIndicators===0)},ariaSlideLabel:function(){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.slide:void 0},ariaPrevButtonLabel:function(){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.prevPageLabel:void 0},ariaNextButtonLabel:function(){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.nextPageLabel:void 0},empty:function(){return!this.value||this.value.length===0},emptyMessageText:function(){var e;return((e=this.$primevue.config)==null||(e=e.locale)==null?void 0:e.emptyMessage)||``}},components:{Button:E,ChevronRightIcon:D,ChevronDownIcon:O,ChevronLeftIcon:k,ChevronUpIcon:A},directives:{ripple:T}},V=[`aria-live`],H=[`data-p-carousel-item-active`,`data-p-carousel-item-start`,`data-p-carousel-item-end`],U=[`aria-hidden`,`aria-label`,`aria-roledescription`,`data-p-carousel-item-active`,`data-p-carousel-item-start`,`data-p-carousel-item-end`],W=[`data-p-active`],G=[`tabindex`,`aria-label`,`aria-current`,`onClick`];function K(e,h,g,_,v,y){var b=n(`Button`);return s(),i(`div`,o({class:e.cx(`root`),role:`region`},e.ptmi(`root`)),[e.$slots.header?(s(),i(`div`,o({key:0,class:e.cx(`header`)},e.ptm(`header`)),[p(e.$slots,`header`)],16)):m(``,!0),y.empty?p(e.$slots,`empty`,{key:2},function(){return[t(u(y.emptyMessageText),1)]}):(s(),i(`div`,o({key:1,class:[e.cx(`contentContainer`),e.containerClass]},e.ptm(`contentContainer`)),[r(`div`,o({class:[e.cx(`content`),e.contentClass],"aria-live":v.allowAutoplay?`polite`:`off`},e.ptm(`content`)),[e.showNavigators?(s(),d(b,o({key:0,class:e.cx(`pcPrevButton`),disabled:y.backwardIsDisabled,"aria-label":y.ariaPrevButtonLabel,unstyled:e.unstyled,onClick:y.navBackward},e.prevButtonProps,{pt:e.ptm(`pcPrevButton`),"data-pc-group-section":`navigator`}),{icon:l(function(t){return[p(e.$slots,`previcon`,{},function(){return[(s(),d(f(y.isVertical()?`ChevronUpIcon`:`ChevronLeftIcon`),o({class:t.icon},e.ptm(`pcPrevButton`).icon),null,16,[`class`]))]})]}),_:3},16,[`class`,`disabled`,`aria-label`,`unstyled`,`onClick`,`pt`])):m(``,!0),r(`div`,o({class:e.cx(`viewport`),style:[{height:y.isVertical()?e.verticalViewPortHeight:`auto`}],onTouchend:h[1]||=function(){return y.onTouchEnd&&y.onTouchEnd.apply(y,arguments)},onTouchstart:h[2]||=function(){return y.onTouchStart&&y.onTouchStart.apply(y,arguments)},onTouchmove:h[3]||=function(){return y.onTouchMove&&y.onTouchMove.apply(y,arguments)}},e.ptm(`viewport`)),[r(`div`,o({ref:`itemsContainer`,class:e.cx(`itemList`),onTransitionend:h[0]||=function(){return y.onTransitionEnd&&y.onTransitionEnd.apply(y,arguments)}},e.ptm(`itemList`)),[y.isCircular()?(s(!0),i(c,{key:0},a(e.value.slice(-1*v.d_numVisible),function(t,n){return s(),i(`div`,o({key:n+`_scloned`,class:e.cx(`itemClone`,{index:n,value:e.value,totalShiftedItems:v.totalShiftedItems,d_numVisible:v.d_numVisible})},{ref_for:!0},e.ptm(`itemClone`),{"data-p-carousel-item-active":v.totalShiftedItems*-1===e.value.length+v.d_numVisible,"data-p-carousel-item-start":n===0,"data-p-carousel-item-end":e.value.slice(-1*v.d_numVisible).length-1===n}),[p(e.$slots,`item`,{data:t,index:n})],16,H)}),128)):m(``,!0),(s(!0),i(c,null,a(e.value,function(t,n){return s(),i(`div`,o({key:n,class:e.cx(`item`,{index:n}),role:`group`,"aria-hidden":y.firstIndex()>n||y.lastIndex()<n||void 0,"aria-label":y.ariaSlideNumber(n),"aria-roledescription":y.ariaSlideLabel},{ref_for:!0},y.getItemPTOptions(`item`,n),{"data-p-carousel-item-active":y.firstIndex()<=n&&y.lastIndex()>=n,"data-p-carousel-item-start":y.firstIndex()===n,"data-p-carousel-item-end":y.lastIndex()===n}),[p(e.$slots,`item`,{data:t,index:n})],16,U)}),128)),y.isCircular()?(s(!0),i(c,{key:1},a(e.value.slice(0,v.d_numVisible),function(t,n){return s(),i(`div`,o({key:n+`_fcloned`,class:e.cx(`itemClone`,{index:n,value:e.value,totalShiftedItems:v.totalShiftedItems,d_numVisible:v.d_numVisible})},{ref_for:!0},e.ptm(`itemClone`)),[p(e.$slots,`item`,{data:t,index:n})],16)}),128)):m(``,!0)],16)],16),e.showNavigators?(s(),d(b,o({key:1,class:e.cx(`pcNextButton`),disabled:y.forwardIsDisabled,"aria-label":y.ariaNextButtonLabel,unstyled:e.unstyled,onClick:y.navForward},e.nextButtonProps,{pt:e.ptm(`pcNextButton`),"data-pc-group-section":`navigator`}),{icon:l(function(t){return[p(e.$slots,`nexticon`,{},function(){return[(s(),d(f(y.isVertical()?`ChevronDownIcon`:`ChevronRightIcon`),o({class:t.class},e.ptm(`pcNextButton`).icon),null,16,[`class`]))]})]}),_:3},16,[`class`,`disabled`,`aria-label`,`unstyled`,`onClick`,`pt`])):m(``,!0)],16,V),y.totalIndicators>=0&&e.showIndicators?(s(),i(`ul`,o({key:0,ref:`indicatorContent`,class:[e.cx(`indicatorList`),e.indicatorsContentClass],onKeydown:h[4]||=function(){return y.onIndicatorKeydown&&y.onIndicatorKeydown.apply(y,arguments)}},e.ptm(`indicatorList`)),[(s(!0),i(c,null,a(y.totalIndicators,function(t,n){return s(),i(`li`,o({key:`p-carousel-indicator-`+n.toString(),class:e.cx(`indicator`,{index:n})},{ref_for:!0},y.getIndicatorPTOptions(`indicator`,n),{"data-p-active":v.d_page===n}),[r(`button`,o({class:e.cx(`indicatorButton`),type:`button`,tabindex:v.d_page===n?`0`:`-1`,"aria-label":y.ariaPageLabel(n+1),"aria-current":v.d_page===n?`page`:void 0,onClick:function(e){return y.onIndicatorClick(e,n)}},{ref_for:!0},y.getIndicatorPTOptions(`indicatorButton`,n)),null,16,G)],16,W)}),128))],16)):m(``,!0)],16)),e.$slots.footer?(s(),i(`div`,o({key:3,class:e.cx(`footer`)},e.ptm(`footer`)),[p(e.$slots,`footer`)],16)):m(``,!0)],16)}B.render=K;export{B as n,M as t};